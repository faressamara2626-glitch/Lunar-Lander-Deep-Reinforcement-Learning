"""
Utilities to compare Baseline DQN vs Advanced DDQN on the same plots.

This script provides helper functions to generate combined curves from in-memory
lists (rewards/losses), matching the "combined plot" requirement in the rubric.
"""

from __future__ import annotations

import os
from typing import Dict, List

import numpy as np
import matplotlib.pyplot as plt


def moving_average(x: List[float], window: int = 100) -> np.ndarray:
    """Compute moving average of a 1D list for smoothing."""
    x = np.asarray(x, dtype=np.float32)
    if x.size == 0:
        return np.array([], dtype=np.float32)
    w = max(1, int(window))
    if x.size < w:
        w = int(x.size)
    kernel = np.ones(w, dtype=np.float32) / float(w)
    return np.convolve(x, kernel, mode="valid")


def plot_reward_and_loss(
    dqn: Dict[str, List[float]],
    ddqn: Dict[str, List[float]],
    outpath: str,
    ma_window: int = 100,
) -> None:
    """
    Create a combined Reward and Loss figure comparing DQN vs DDQN.

    Expected keys in each dict:
      - "rewards": episodic total rewards (list)
      - "losses": training losses (list; can contain NaNs)
    """
    rewards_dqn = dqn["rewards"]
    rewards_ddqn = ddqn["rewards"]
    losses_dqn = np.asarray(dqn["losses"], dtype=np.float32)
    losses_ddqn = np.asarray(ddqn["losses"], dtype=np.float32)

    fig, axes = plt.subplots(2, 1, figsize=(10, 8))

    # Reward
    ax = axes[0]
    ax.plot(rewards_dqn, alpha=0.15, label="Baseline DQN (raw)")
    ax.plot(moving_average(rewards_dqn, ma_window), label=f"Baseline DQN (MA{ma_window})")
    ax.plot(rewards_ddqn, alpha=0.15, label="Advanced DDQN (raw)")
    ax.plot(moving_average(rewards_ddqn, ma_window), label=f"Advanced DDQN (MA{ma_window})")
    ax.axhline(200.0, linestyle="--", linewidth=1.0, label="Solved threshold (200)")
    ax.set_title("Reward vs Episodes (DQN vs DDQN)")
    ax.set_xlabel("Episode")
    ax.set_ylabel("Total Reward")
    ax.grid(True, alpha=0.3)
    ax.legend()

    # Loss
    ax = axes[1]
    ld = losses_dqn[np.isfinite(losses_dqn)]
    la = losses_ddqn[np.isfinite(losses_ddqn)]
    ax.plot(ld, alpha=0.15, label="Baseline DQN (raw)")
    ax.plot(moving_average(ld.tolist(), ma_window), label=f"Baseline DQN (MA{ma_window})")
    ax.plot(la, alpha=0.15, label="Advanced DDQN (raw)")
    ax.plot(moving_average(la.tolist(), ma_window), label=f"Advanced DDQN (MA{ma_window})")
    ax.set_title("Loss vs Updates (DQN vs DDQN)")
    ax.set_xlabel("Update index")
    ax.set_ylabel("Huber Loss")
    ax.grid(True, alpha=0.3)
    ax.legend()

    plt.tight_layout()
    os.makedirs(os.path.dirname(outpath) or ".", exist_ok=True)
    plt.savefig(outpath, dpi=150)
    plt.close(fig)
