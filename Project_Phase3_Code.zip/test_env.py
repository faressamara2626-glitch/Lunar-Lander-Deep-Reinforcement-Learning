# test_env.py
from __future__ import annotations

import gymnasium as gym
import numpy as np
from gymnasium import spaces


class FuelWrapper(gym.Wrapper):
    """
    Extends LunarLander observation from 8D -> 9D by appending fuel_fraction in [0, 1].

    Key design (for strong learning + clean comparisons):
    - During baseline/advanced training, keep the environment reward *unchanged*.
      Fuel is only an additional state feature.
    - Optional shaping exists but is OFF by default; only turn it on if your professor
      explicitly expects fuel-efficiency shaping beyond the original task.
    """

    def __init__(
        self,
        env: gym.Env,
        initial_fuel: float = 2.0,
        fuel_cost_main: float = 0.02,
        fuel_cost_side: float = 0.005,
        enable_shaping: bool = False,
        fuel_penalty_coef: float = 5.0,
        terminate_on_empty: bool = False,
        fuel_depletion_penalty: float = -20.0,
    ):
        super().__init__(env)

        # Expand observation space: original 8 + fuel_fraction
        low = np.append(self.env.observation_space.low, 0.0)
        high = np.append(self.env.observation_space.high, 1.0)
        self.observation_space = spaces.Box(low=low, high=high, dtype=np.float32)

        self.initial_fuel = float(initial_fuel)
        self.fuel_cost_main = float(fuel_cost_main)
        self.fuel_cost_side = float(fuel_cost_side)

        self.enable_shaping = bool(enable_shaping)
        self.fuel_penalty_coef = float(fuel_penalty_coef)
        self.terminate_on_empty = bool(terminate_on_empty)
        self.fuel_depletion_penalty = float(fuel_depletion_penalty)

        self.fuel = self.initial_fuel

    def _fuel_fraction(self) -> float:
        if self.initial_fuel <= 0:
            return 0.0
        return float(np.clip(self.fuel / self.initial_fuel, 0.0, 1.0))

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.fuel = self.initial_fuel
        obs = np.append(obs, self._fuel_fraction()).astype(np.float32)
        info = dict(info)
        info["fuel"] = float(self.fuel)
        info["fuel_fraction"] = self._fuel_fraction()
        return obs, info

    def step(self, action: int):
        next_obs, reward, terminated, truncated, info = self.env.step(action)

        # Fuel consumption based on action:
        # 0: do nothing, 1: left engine, 2: main engine, 3: right engine
        fuel_used = 0.0
        if action == 2:
            fuel_used = self.fuel_cost_main
        elif action in (1, 3):
            fuel_used = self.fuel_cost_side

        self.fuel = max(0.0, self.fuel - fuel_used)

        # Optional shaping: penalize fuel usage slightly (OFF by default)
        if self.enable_shaping and fuel_used > 0.0:
            reward = float(reward) - self.fuel_penalty_coef * float(fuel_used)

        # Optional terminate on empty fuel (OFF by default)
        if self.terminate_on_empty and (self.fuel <= 0.0) and (not terminated):
            terminated = True
            reward = float(reward) + self.fuel_depletion_penalty
            info = dict(info)
            info["fuel_depleted"] = True

        info = dict(info)
        info["fuel"] = float(self.fuel)
        info["fuel_fraction"] = self._fuel_fraction()

        next_obs = np.append(next_obs, self._fuel_fraction()).astype(np.float32)
        return next_obs, float(reward), bool(terminated), bool(truncated), info


def make_env(seed: int | None = None) -> gym.Env:
    """
    Factory to create the wrapped environment with deterministic seeding.
    """
    env = gym.make("LunarLander-v3")
    env = FuelWrapper(
        env,
        initial_fuel=2.0,
        fuel_cost_main=0.02,
        fuel_cost_side=0.005,
        enable_shaping=False,      # keep OFF for clean baseline/advanced comparison
        terminate_on_empty=False,  # keep OFF initially
    )
    if seed is not None:
        env.reset(seed=seed)
        env.action_space.seed(seed)
        env.observation_space.seed(seed)
    return env


if __name__ == "__main__":
    env = make_env(seed=0)
    print("Observation space:", env.observation_space)
    print("Action space:", env.action_space)

    obs, info = env.reset()
    print("Initial obs shape:", obs.shape, "fuel_fraction:", info["fuel_fraction"])

    a = env.action_space.sample()
    obs2, r, term, trunc, info2 = env.step(a)
    print("Step -> obs shape:", obs2.shape, "reward:", r, "fuel_fraction:", info2["fuel_fraction"])
    env.close()
