# run_dqn.py
from __future__ import annotations

import os
from dataclasses import asdict
from typing import Dict, Any, List, Tuple, Optional

import numpy as np
import matplotlib.pyplot as plt

from test_env import make_env
from dqn_agent import DQNAgent, DQNHyperParams


# -----------------------------
# Metrics helpers (Phase 1 plan)
# -----------------------------
def moving_average(x: List[float], window: int = 100) -> np.ndarray:
    if len(x) == 0:
        return np.array([])
    w = min(window, len(x))
    kernel = np.ones(w, dtype=np.float32) / w
    return np.convolve(np.array(x, dtype=np.float32), kernel, mode="valid")


def is_successful_landing(total_reward: float, terminated: bool) -> int:
    """
    A practical success definition:
      - Episode ended naturally (terminated=True)
      - Total episodic reward >= 200
    This matches the common "solved" threshold for LunarLander.
    """
    return int(bool(terminated) and (total_reward >= 200.0))


def compute_convergence_episode(
    rewards: List[float],
    window: int = 100,
    threshold: float = 200.0,
    patience_windows: int = 3,
) -> Optional[int]:
    """
    Episodes-to-convergence:
    First episode index where MA(window) >= threshold and stays >= threshold for
    `patience_windows` consecutive MA points.

    MA index i corresponds to episode (i + window) in 1-indexed terms.
    """
    ma = moving_average(rewards, window=window)
    if ma.size == 0:
        return None

    needed = patience_windows
    for i in range(0, len(ma) - needed + 1):
        if np.all(ma[i : i + needed] >= threshold):
            return int(i + window)
    return None


def safe_float(x: Any) -> float:
    try:
        return float(x)
    except Exception:
        return float("nan")


# -----------------------------
# Training / Evaluation loops
# -----------------------------
def train(
    agent: DQNAgent,
    num_episodes: int,
    seed: int,
    outdir: str,
    max_steps_per_episode: int = 1000,
    ma_window: int = 100,
) -> Dict[str, List[float]]:
    env = make_env(seed=seed)

    rewards: List[float] = []
    losses: List[float] = []
    success_flags: List[float] = []
    fuel_on_success: List[float] = []  # fuel_fraction at end of episode, NaN if not success/unknown

    for ep in range(1, num_episodes + 1):
        obs, _ = env.reset()
        ep_reward = 0.0
        ep_losses: List[float] = []
        terminated = False
        truncated = False
        last_info: Dict[str, Any] = {}

        for _ in range(max_steps_per_episode):
            action = agent.choose_action(obs)
            next_obs, reward, terminated, truncated, info = env.step(action)
            last_info = info

            agent.remember(obs, action, reward, next_obs, terminated)
            loss = agent.learn_step()
            if loss is not None:
                ep_losses.append(loss)

            ep_reward += float(reward)
            obs = next_obs

            if terminated or truncated:
                break

        agent.update_epsilon()

        succ = is_successful_landing(ep_reward, terminated)
        fuel_frac = safe_float(last_info.get("fuel_fraction", np.nan))
        # Only keep fuel reading for successful landings (else NaN)
        fuel_frac = fuel_frac if succ == 1 else float("nan")

        rewards.append(ep_reward)
        losses.append(float(np.mean(ep_losses)) if len(ep_losses) > 0 else float("nan"))
        success_flags.append(float(succ))
        fuel_on_success.append(float(fuel_frac))

        if ep % 10 == 0 or ep == 1:
            avg_loss = losses[-1]
            print(
                f"Episode {ep:4d}/{num_episodes} | "
                f"Reward: {ep_reward:8.2f} | "
                f"Epsilon: {agent.epsilon:6.3f} | "
                f"AvgLoss: {avg_loss:8.4f} | "
                f"Success: {succ}"
            )

    env.close()

    os.makedirs(outdir, exist_ok=True)

    # Convergence episode (your Phase 1 plan)
    conv_ep = compute_convergence_episode(rewards, window=ma_window, threshold=200.0, patience_windows=3)

    # Save summary text
    with open(os.path.join(outdir, "dqn_train_summary.txt"), "w", encoding="utf-8") as f:
        f.write("DQN Training Summary\n")
        f.write("====================\n")
        f.write(f"Episodes: {num_episodes}\n")
        f.write(f"MovingAvgWindow: {ma_window}\n")
        f.write(f"ConvergenceEpisode(MA>=200 for 3 windows): {conv_ep}\n")
        f.write(f"FinalEpsilon: {agent.epsilon}\n")

    return {
        "rewards": rewards,
        "losses": losses,
        "success": success_flags,
        "fuel_success": fuel_on_success,
    }


def evaluate(
    agent: DQNAgent,
    num_trials: int,
    seed: int,
    max_steps: int = 1000,
) -> Dict[str, float]:
    env = make_env(seed=seed)
    rewards: List[float] = []
    success: List[float] = []
    fuels: List[float] = []

    for _ in range(num_trials):
        obs, _ = env.reset()
        total = 0.0
        terminated = False
        truncated = False
        last_info: Dict[str, Any] = {}

        while not (terminated or truncated):
            action = agent.choose_action(obs, greedy=True)
            obs, reward, terminated, truncated, info = env.step(action)
            last_info = info
            total += float(reward)
            if max_steps is not None and max_steps > 0 and len(rewards) < 10_000:
                # max_steps handled by env truncation typically; keep simple here
                pass

        succ = is_successful_landing(total, terminated)
        fuel_frac = safe_float(last_info.get("fuel_fraction", np.nan))
        rewards.append(total)
        success.append(float(succ))
        if succ == 1 and np.isfinite(fuel_frac):
            fuels.append(float(fuel_frac))

    env.close()

    mean_reward = float(np.mean(rewards))
    std_reward = float(np.std(rewards))
    success_rate = float(np.mean(success))
    avg_fuel_success = float(np.mean(fuels)) if len(fuels) > 0 else float("nan")

    return {
        "mean_reward": mean_reward,
        "std_reward": std_reward,
        "success_rate": success_rate,
        "avg_fuel_on_success": avg_fuel_success,
    }


# -----------------------------
# Plotting
# -----------------------------
def plot_curves(series: Dict[str, List[float]], outdir: str, ma_window: int = 100) -> None:
    os.makedirs(outdir, exist_ok=True)

    rewards = series["rewards"]
    losses = series["losses"]
    success = series["success"]
    fuel_success = series["fuel_success"]

    # 1) Reward moving average
    plt.figure()
    ma_r = moving_average(rewards, window=ma_window)
    plt.plot(np.arange(len(ma_r)), ma_r)
    plt.xlabel(f"Episode (MA window={ma_window})")
    plt.ylabel("Cumulative Reward")
    plt.title("DQN: Moving Average Reward")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "dqn_reward_curve.png"), dpi=150)

    # 2) Loss curve (MA; ignore leading NaNs)
    plt.figure()
    losses_arr = np.array(losses, dtype=np.float32)
    valid = np.isfinite(losses_arr)
    if valid.sum() > 0:
        losses_valid = losses_arr[valid].tolist()
        ma_l = moving_average(losses_valid, window=min(ma_window, len(losses_valid)))
        plt.plot(np.arange(len(ma_l)), ma_l)
    plt.xlabel("Update index (smoothed)")
    plt.ylabel("Huber Loss")
    plt.title("DQN: Smoothed Training Loss")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "dqn_loss_curve.png"), dpi=150)

    # 3) Success rate (MA)
    plt.figure()
    ma_s = moving_average(success, window=ma_window)
    plt.plot(np.arange(len(ma_s)), ma_s)
    plt.xlabel(f"Episode (MA window={ma_window})")
    plt.ylabel("Success Rate")
    plt.ylim(0.0, 1.0)
    plt.title("DQN: Moving Average Success Rate")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "dqn_success_rate_curve.png"), dpi=150)

    # 4) Fuel remaining at landing (MA over filled values)
    plt.figure()
    fuels = np.array(fuel_success, dtype=np.float32)
    valid = np.isfinite(fuels)
    if valid.sum() > 0:
        fill = float(np.nanmean(fuels))
        fuels_filled = np.where(valid, fuels, fill).tolist()
        ma_f = moving_average(fuels_filled, window=ma_window)
        plt.plot(np.arange(len(ma_f)), ma_f)
    plt.xlabel(f"Episode (MA window={ma_window})")
    plt.ylabel("Fuel Fraction at Successful Landing")
    plt.ylim(0.0, 1.0)
    plt.title("DQN: Fuel Remaining at Landing (Smoothed)")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "dqn_fuel_remaining_curve.png"), dpi=150)

    print("Saved DQN plots to:", outdir)


# -----------------------------
# Main
# -----------------------------
def main():
    # Experiment settings (override via environment variables if you want)
    SEED = int(os.environ.get("SEED", "0"))
    NUM_EPISODES = int(os.environ.get("NUM_EPISODES", "3500"))
    EVAL_TRIALS = int(os.environ.get("EVAL_TRIALS", "100"))
    OUTDIR = os.environ.get("OUTDIR", "outputs/dqn")
    MA_WINDOW = int(os.environ.get("MA_WINDOW", "100"))

    # Hyperparameters (keep identical between DQN and DDQN scripts for fair comparison)
    h = DQNHyperParams(
        gamma=0.99,
        lr=5e-4,
        batch_size=128,
        buffer_capacity=300_000,
        start_learning=10_000,
        train_every=4,
        target_update_every=5_000,
        grad_clip_norm=10.0,
    )

    # Build env once just to read dims
    env = make_env(seed=SEED)
    state_dim = int(env.observation_space.shape[0])
    action_dim = int(env.action_space.n)
    env.close()

    agent = DQNAgent(
        state_dim=state_dim,
        action_dim=action_dim,
        hidden_sizes=(256, 256),
        epsilon_start=1.0,
        epsilon_min=0.05,
        epsilon_decay=0.999,
        double_dqn=False,
        hparams=h,
        seed=SEED,
    )

    print(f"Running BASELINE DQN | seed={SEED} episodes={NUM_EPISODES}")
    series = train(agent, num_episodes=NUM_EPISODES, seed=SEED, outdir=OUTDIR, ma_window=MA_WINDOW)

# Save raw metrics for combined plots/comparison
np.savez(
    os.path.join(OUTDIR, "dqn_metrics.npz"),
    rewards=np.array(series["rewards"], dtype=np.float32),
    losses=np.array(series["losses"], dtype=np.float32),
    success=np.array(series["success"], dtype=np.float32),
    fuel_success=np.array(series["fuel_success"], dtype=np.float32),
)

    # Save model
    os.makedirs(OUTDIR, exist_ok=True)
    agent.save_model(os.path.join(OUTDIR, "dqn_baseline.pth"))

    # Evaluate
    eval_stats = evaluate(agent, num_trials=EVAL_TRIALS, seed=SEED + 123)
    print(
        f"DQN evaluation ({EVAL_TRIALS} trials): "
        f"mean={eval_stats['mean_reward']:.2f}, std={eval_stats['std_reward']:.2f}, "
        f"success_rate={eval_stats['success_rate']*100:.1f}%, "
        f"avg_fuel_on_success={eval_stats['avg_fuel_on_success']:.3f}"
    )

    # Save eval + hparams
    with open(os.path.join(OUTDIR, "dqn_eval_summary.txt"), "w", encoding="utf-8") as f:
        f.write("DQN Evaluation Summary\n")
        f.write("======================\n")
        for k, v in eval_stats.items():
            f.write(f"{k}: {v}\n")

    with open(os.path.join(OUTDIR, "hyperparameters.txt"), "w", encoding="utf-8") as f:
        f.write("DQNHyperParams\n")
        f.write("=============\n")
        for k, v in asdict(h).items():
            f.write(f"{k}: {v}\n")
        f.write("\nAgent\n=====\n")
        f.write("double_dqn: False\n")
        f.write("hidden_sizes: (256, 256)\n")
        f.write("epsilon_start: 1.0\n")
        f.write("epsilon_min: 0.05\n")
        f.write("epsilon_decay: 0.999\n")
        f.write(f"seed: {SEED}\n")

    # Plots
    plot_curves(series, outdir=OUTDIR, ma_window=MA_WINDOW)


if __name__ == "__main__":
    main()
