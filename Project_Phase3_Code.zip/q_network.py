# q_network.py
from __future__ import annotations

from typing import Sequence
import torch
import torch.nn as nn


class QNetwork(nn.Module):
    """
    Simple MLP Q-network for discrete-action DQN-style agents.

    Input:  state vector (e.g., 9D for LunarLander + fuel feature)
    Output: Q-values for each discrete action (e.g., 4 actions)

    Notes:
    - Uses ReLU activations.
    - Uses a standard weight initialization to help stable training.
    """

    def __init__(self, state_dim: int, action_dim: int, hidden_sizes: Sequence[int] = (256, 256)):
        super().__init__()

        layers: list[nn.Module] = []
        in_dim = state_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.ReLU())
            in_dim = h
        layers.append(nn.Linear(in_dim, action_dim))

        self.net = nn.Sequential(*layers)
        self._init_weights()

    def _init_weights(self) -> None:
        # Kaiming init for ReLU layers, small init for last layer
        for m in self.net:
            if isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight, nonlinearity="relu")
                nn.init.zeros_(m.bias)

        # Last layer: slightly smaller init helps early stability
        last = None
        for m in reversed(self.net):
            if isinstance(m, nn.Linear):
                last = m
                break
        if last is not None:
            nn.init.uniform_(last.weight, a=-1e-3, b=1e-3)
            nn.init.zeros_(last.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [batch, state_dim] float tensor
        returns: [batch, action_dim]
        """
        return self.net(x)
