# dqn_agent.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence, Tuple
import os
import random

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from q_network import QNetwork
from replay_buffer import ReplayBuffer


@dataclass
class DQNHyperParams:
    gamma: float = 0.99
    lr: float = 5e-4
    batch_size: int = 128
    buffer_capacity: int = 300_000
    start_learning: int = 10_000
    train_every: int = 4
    target_update_every: int = 5_000
    grad_clip_norm: float = 10.0


class DQNAgent:
    """
    DQN / Double DQN agent for discrete-action environments.

    Key features:
    - Experience replay
    - Target network (hard update every N steps)
    - Epsilon-greedy exploration with decay
    - Huber loss
    - Optional Double DQN target computation
    - Gradient clipping for stability
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden_sizes: Sequence[int] = (256, 256),
        epsilon_start: float = 1.0,
        epsilon_min: float = 0.05,
        epsilon_decay: float = 0.999,
        double_dqn: bool = False,
        hparams: DQNHyperParams = DQNHyperParams(),
        device: Optional[str] = None,
        seed: int = 0,
    ):
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.double_dqn = bool(double_dqn)
        self.h = hparams

        # Device
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)

        # Seeding for reproducibility
        self._set_seed(seed)

        # Networks
        self.q_net = QNetwork(self.state_dim, self.action_dim, hidden_sizes=hidden_sizes).to(self.device)
        self.target_net = QNetwork(self.state_dim, self.action_dim, hidden_sizes=hidden_sizes).to(self.device)
        self.target_net.load_state_dict(self.q_net.state_dict())
        self.target_net.eval()

        # Replay buffer
        self.buffer = ReplayBuffer(self.h.buffer_capacity, self.state_dim)

        # Optimizer + loss
        self.optimizer = optim.Adam(self.q_net.parameters(), lr=self.h.lr)
        self.loss_fn = nn.SmoothL1Loss()  # Huber

        # Epsilon schedule
        self.epsilon = float(epsilon_start)
        self.epsilon_min = float(epsilon_min)
        self.epsilon_decay = float(epsilon_decay)

        # Counters
        self.total_steps = 0
        self.learn_steps = 0

    def _set_seed(self, seed: int) -> None:
        seed = int(seed)
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        # For deterministic behavior (can reduce performance slightly)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    def choose_action(self, state: np.ndarray, greedy: bool = False) -> int:
        """
        Epsilon-greedy action selection.
        - greedy=True ignores epsilon and always takes argmax.
        """
        if (not greedy) and (np.random.rand() < self.epsilon):
            return int(np.random.randint(self.action_dim))

        state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)  # [1, state_dim]
        with torch.no_grad():
            q_vals = self.q_net(state_t)  # [1, action_dim]
        return int(torch.argmax(q_vals, dim=1).item())

    def remember(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, done: bool) -> None:
        self.buffer.add(state, action, reward, next_state, done)

    def update_epsilon(self) -> None:
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    def _hard_update_target(self) -> None:
        self.target_net.load_state_dict(self.q_net.state_dict())

    def learn_step(self) -> Optional[float]:
        """
        Perform one learning update step if:
        - buffer has enough transitions
        - we are on the correct update frequency
        Returns:
            loss value (float) if updated, else None
        """
        self.total_steps += 1

        # Wait until buffer has enough samples
        if not self.buffer.is_ready(self.h.batch_size, self.h.start_learning):
            return None

        # Update only every train_every steps
        if self.total_steps % self.h.train_every != 0:
            return None

        batch = self.buffer.sample(self.h.batch_size)

        states = torch.tensor(batch.states, dtype=torch.float32, device=self.device)         # [B, state_dim]
        actions = torch.tensor(batch.actions, dtype=torch.int64, device=self.device)        # [B]
        rewards = torch.tensor(batch.rewards, dtype=torch.float32, device=self.device)      # [B]
        next_states = torch.tensor(batch.next_states, dtype=torch.float32, device=self.device)
        dones = torch.tensor(batch.dones, dtype=torch.float32, device=self.device)          # [B]

        # Current Q(s,a)
        q_values = self.q_net(states)  # [B, A]
        q_sa = q_values.gather(1, actions.unsqueeze(1)).squeeze(1)  # [B]

        with torch.no_grad():
            if self.double_dqn:
                # DDQN: action selection via online network, evaluation via target network
                next_actions = torch.argmax(self.q_net(next_states), dim=1)  # [B]
                next_q = self.target_net(next_states).gather(1, next_actions.unsqueeze(1)).squeeze(1)  # [B]
            else:
                # DQN: max over target network directly
                next_q = torch.max(self.target_net(next_states), dim=1).values  # [B]

            target = rewards + (1.0 - dones) * self.h.gamma * next_q  # [B]

        loss = self.loss_fn(q_sa, target)

        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()

        # Gradient clipping for stability
        if self.h.grad_clip_norm is not None and self.h.grad_clip_norm > 0:
            nn.utils.clip_grad_norm_(self.q_net.parameters(), self.h.grad_clip_norm)

        self.optimizer.step()

        self.learn_steps += 1

        # Target network update
        if self.total_steps % self.h.target_update_every == 0:
            self._hard_update_target()

        return float(loss.item())

    def save_model(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        torch.save(
            {
                "q_net": self.q_net.state_dict(),
                "target_net": self.target_net.state_dict(),
                "optimizer": self.optimizer.state_dict(),
                "epsilon": self.epsilon,
                "total_steps": self.total_steps,
                "learn_steps": self.learn_steps,
                "double_dqn": self.double_dqn,
                "hparams": self.h,
                "state_dim": self.state_dim,
                "action_dim": self.action_dim,
            },
            path,
        )

    def load_model(self, path: str) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.q_net.load_state_dict(ckpt["q_net"])
        self.target_net.load_state_dict(ckpt["target_net"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self.epsilon = float(ckpt.get("epsilon", self.epsilon))
        self.total_steps = int(ckpt.get("total_steps", 0))
        self.learn_steps = int(ckpt.get("learn_steps", 0))
        # Note: we keep self.double_dqn as configured by your script for clarity.
