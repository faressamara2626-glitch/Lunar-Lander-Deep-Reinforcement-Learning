# 14469 RL Project — Phase 03 (Group 8)
**Task:** Intelligent Lunar Landing with Resource Management  
**Baseline:** DQN  
**Advanced:** Double DQN (DDQN)  
**Environment:** Gymnasium `LunarLander-v3` (Discrete) with Box2D

This codebase contains:
- `test_env.py` — environment wrapper (adds fuel feature to the observation)
- `q_network.py` — Q-network definition (PyTorch)
- `replay_buffer.py` — experience replay buffer
- `dqn_agent.py` — DQN / DDQN agent logic
- `run_dqn.py` — training & evaluation for baseline DQN
- `run_ddqn.py` — training & evaluation for advanced DDQN
- `compare_plots.py` — REQUIRED combined plots (DQN vs DDQN on same graphs)
- `draw_architecture.py` — network architecture figure generator for the report

---

## 1) Setup

### 1.1 Create and activate a virtual environment (recommended)
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
```

### 1.2 Install dependencies
```bash
pip install -r requirements.txt
```

### 1.3 If Box2D installation fails
Gymnasium Box2D environments may require SWIG to build `box2d-py`:
```bash
pip install swig
pip install "gymnasium[box2d]"
```
Docs: https://gymnasium.farama.org/environments/box2d/

> Some OSes may require installing SWIG via the system package manager as well.

---

## 2) Train Baseline DQN
```bash
python run_dqn.py
```

Expected outputs (default) under `outputs/dqn/`:
- model: `dqn_baseline.pth`
- plots: `dqn_reward_curve.png`, `dqn_loss_curve.png`, etc.
- summaries: `dqn_train_summary.txt`, `dqn_eval_summary.txt`
- hyperparameters: `hyperparameters.txt`
- raw metrics for combined plots: `dqn_metrics.npz`

---

## 3) Train Advanced Double DQN (DDQN)
```bash
python run_ddqn.py
```

Expected outputs (default) under `outputs/ddqn/`:
- model: `ddqn_advanced.pth`
- plots: `ddqn_reward_curve.png`, `ddqn_loss_curve.png`, etc.
- summaries: `ddqn_train_summary.txt`, `ddqn_eval_summary.txt`
- hyperparameters: `hyperparameters.txt`
- raw metrics for combined plots: `ddqn_metrics.npz`

---

## 4) REQUIRED — Combined comparison plots (DQN vs DDQN on same graphs)
Phase 03 requires combined plots when comparing agents. After running both trainings:
```bash
python compare_plots.py
```

Outputs under `outputs/compare/`:
- `combined_reward_curve.png`  (learning speed)
- `combined_loss_curve.png`    (loss convergence)
- `combined_success_rate_curve.png`
- `combined_fuel_remaining_curve.png`

---

## 5) REQUIRED — Network architecture figure (for the report)
Generate a simple Q-network architecture diagram:
```bash
python draw_architecture.py
```

Output:
- `outputs/figures/q_network_architecture.png`

---

## 6) Reproducibility (environment variables)
The training scripts support overriding key settings without editing code:
- `SEED` (default: 0)
- `NUM_EPISODES`
- `EVAL_TRIALS` (default: 100)
- `OUTDIR`
- `MA_WINDOW` (default: 100)

Example:
```bash
SEED=1 NUM_EPISODES=3000 EVAL_TRIALS=100 python run_dqn.py
SEED=1 NUM_EPISODES=2500 EVAL_TRIALS=100 python run_ddqn.py
python compare_plots.py
```

---

## 7) Report metric reminder (Phase 03 requirement)
In the report, include:
- **Final performance:** mean reward over **100 evaluation episodes** after training is frozen (greedy policy)
- **Stability:** standard deviation / variance of evaluation reward
- **Combined plots:** reward and loss (DQN vs DDQN on the same graphs)
