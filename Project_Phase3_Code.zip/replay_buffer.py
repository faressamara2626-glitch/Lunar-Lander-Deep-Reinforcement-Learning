# replay_buffer.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple
import numpy as np


@dataclass
class Batch:
    states: np.ndarray       # [B, state_dim]
    actions: np.ndarray      # [B] int64
    rewards: np.ndarray      # [B] float32
    next_states: np.ndarray  # [B, state_dim]
    dones: np.ndarray        # [B] float32 (1.0 if done else 0.0)


class ReplayBuffer:
    """
    Fixed-size replay buffer for off-policy RL (DQN / DDQN).

    Stores transitions (s, a, r, s', done).
    Samples random mini-batches for stable learning.

    Implementation details:
    - Preallocates numpy arrays for speed.
    - Uses a circular pointer to overwrite old data when full.
    """

    def __init__(self, capacity: int, state_dim: int):
        self.capacity = int(capacity)
        self.state_dim = int(state_dim)

        self._states = np.zeros((self.capacity, self.state_dim), dtype=np.float32)
        self._actions = np.zeros((self.capacity,), dtype=np.int64)
        self._rewards = np.zeros((self.capacity,), dtype=np.float32)
        self._next_states = np.zeros((self.capacity, self.state_dim), dtype=np.float32)
        self._dones = np.zeros((self.capacity,), dtype=np.float32)

        self._ptr = 0
        self._size = 0

    def __len__(self) -> int:
        return self._size

    def add(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, done: bool) -> None:
        idx = self._ptr

        self._states[idx] = state
        self._actions[idx] = int(action)
        self._rewards[idx] = float(reward)
        self._next_states[idx] = next_state
        self._dones[idx] = 1.0 if bool(done) else 0.0

        self._ptr = (self._ptr + 1) % self.capacity
        self._size = min(self._size + 1, self.capacity)

    def sample(self, batch_size: int) -> Batch:
        if self._size < batch_size:
            raise ValueError(f"Not enough samples to draw batch_size={batch_size}. Current size={self._size}")

        idxs = np.random.randint(0, self._size, size=batch_size)

        return Batch(
            states=self._states[idxs],
            actions=self._actions[idxs],
            rewards=self._rewards[idxs],
            next_states=self._next_states[idxs],
            dones=self._dones[idxs],
        )

    def is_ready(self, batch_size: int, start_learning: int) -> bool:
        """
        Returns True when buffer is sufficiently filled to start learning.
        """
        return (self._size >= batch_size) and (self._size >= start_learning)
